<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => 'Annonce',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => 'Le module d\'annonce affiche un bulletin en haut de la page d\'accueil',
    'Notice content' => 'Annonce',
    'Save' => 'Sauvegarder'
];